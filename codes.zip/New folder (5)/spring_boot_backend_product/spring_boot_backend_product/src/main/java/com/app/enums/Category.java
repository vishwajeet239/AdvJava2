package com.app.enums;

public enum Category {

	FASHION,ELECTRONICS
}
